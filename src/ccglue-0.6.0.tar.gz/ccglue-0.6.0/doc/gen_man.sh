help2man -S "Hari Rangarajan <hariranga@users.sourceforge.net>" --no-info -i ccglue.include ccglue -o ccglue.1
help2man -S "Hari Rangarajan <hariranga@users.sourceforge.net>" --no-info -i ccglue_tracer.include ccglue_tracer -o ccglue_tracer.1

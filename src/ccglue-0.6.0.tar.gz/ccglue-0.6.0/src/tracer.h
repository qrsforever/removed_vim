#ifndef CCGLUE_TRACER
#define CCGLUE_TRACER

namespace ccglue {
    struct trace_direction {
        enum {
            forward='f',
            reverse='r'
        };
    };
};

#endif
